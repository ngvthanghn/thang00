var wait = global.nodemodule["wait-for-stuff"];
var fs = require('fs');
var path = require('path');
!global.data.countchat ? global.data.countchat = {} : "";

var start = function(type, data){
	var allow = false;
	var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
	var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
	if (adminIDs.indexOf(data.msgdata.senderID) != -1) {
		!global.data.countchat[data.msgdata.threadID] ? global.data.countchat[data.msgdata.threadID] = {} : "";
		var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
		var participantIDs = threadInfo.participantIDs;
		for(i=0;i<participantIDs.length;i++){
			!global.data.countchat[data.msgdata.threadID][participantIDs[i]] ? global.data.countchat[data.msgdata.threadID][participantIDs[i]] = 0 : "";
		}
	}
	else{
		return {
			handler: "internal",
			   data: "admin only!"
		}
	}
	if(global.data.countchat[data.msgdata.threadID] != undefined){
		return {
			handler: "internal",
			   data: "countchat started successfully!"
		}
	}
	else{
		return {
			handler: "internal",
			   data: "error while starting countchat!"
		}
	}

}
var stop = function(type, data){
	var allow = false;
	var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
	var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
	if (adminIDs.indexOf(data.msgdata.senderID) != -1) {
		delete global.data.countchat[data.msgdata.threadID];
	}
	else{
		return {
			handler: "internal",
			   data: "admin only!"
		}
	}
	if(global.data.countchat[data.msgdata.threadID] == undefined){
		return {
			handler: "internal",
			   data: "countchat stopped successfully!"
		}
	}
	else{
		return {
			handler: "internal",
			   data: "error while stopping countchat!"
		}
	}
}

var reset = function(type, data){
	for (var member in global.data.countchat[data.msgdata.threadID]) delete global.data.countchat[data.msgdata.threadID][member];
	var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
	var participantIDs = threadInfo.participantIDs;
	for(i=0;i<participantIDs.length;i++){
		!global.data.countchat[data.msgdata.threadID][participantIDs[i]] ? global.data.countchat[data.msgdata.threadID][participantIDs[i]] = 0 : "";
	}
	return{
		handler: 'internal',
		data: 'reset countchat successfully!'
	}
}

var show = function(type, data){
	if(data.args[1] != undefined){
		if(data.args[1] == "all"){
			var IDs = Object.keys(global.data.countchat[data.msgdata.threadID]);
			var thread = global.data.countchat[data.msgdata.threadID];
			var facebook = data.facebookapi;
			var msg = data.msgdata;
		    data.facebookapi.getUserInfo(IDs, (err, info) => {
				var speech = "";
				var length = Object.keys(info).length;
				for(i=0;i<length;i++){
					var cname = info[IDs[i]].name;
					var turn = thread[IDs[i]];
					var data = `${cname}: ${turn} tin nhắn\r\n`;
					speech = speech + data;
				}
				facebook.sendMessage({
					body: speech,
				}, msg.threadID);
		    });
		}
	}
}
var chathook = function(type, data){
    if(Object.keys(global.data.countchat).indexOf(data.msgdata.threadID) != -1){
		!global.data.countchat[data.msgdata.threadID] ? global.data.countchat[data.msgdata.threadID] = {} : "";
		if(Object.keys(global.data.countchat[data.msgdata.threadID]).indexOf(data.msgdata.senderID) != -1){
			global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] = global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] + 1;
		}
		else{
			!global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] ? global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] = 0 : "";
		}
	}
}
var sizeObject = function(object) {
	return Object.keys(object).length;
};













/*
var startcountchat = function(type, data){
	if (data.msgdata.isGroup) {
		var allowRun = false;
		var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
		var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
		if (adminIDs.indexOf(data.msgdata.senderID) != -1) {
			allowRun = true;
		}
		if(allowRun == true){
			typeof global.data.countchat[data.msgdata.threadID] != "object" ? global.data.countchat[data.msgdata.threadID] = {} : "";
            if(global.data.countchat[data.msgdata.threadID] != null){
				global.data.countchat[data.msgdata.threadID].allow = 1;
    	        return {
	            	handler: "internal",
	        	   	data: "countchat started successfully!"
	    	    }
        	}
		}
		return {
			handler: "internal",
			   data: "admin only!"
		}
	}
	return {
		handler: "internal",
		   data: "chỉ hoạt động trong group!"
	}
}
var sizeObject = function(object) {
	return Object.keys(object).length;
};
var getID = function (msgdata, type) {
	var id = "0";
	switch (type) {
		case "Facebook":
			id = "FB-" + msgdata.senderID;
			break;
	}
	return id;
}
var countchat = function(type, data){
	typeof global.data.countchat[data.msgdata.threadID] != "object" ? global.data.countchat[data.msgdata.threadID] = {} : "";
	!global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] ? global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] = [] : "";
	if (sizeObject(data.mentions)) {
		delete data1;
		var data1 = "";
		var check = 1;
		for (var y in data.mentions) {
			var id = y;
			var times = global.data.countchat[data.msgdata.threadID][(id.slice(3,id.length))];
			if (times == undefined){
				times = 0;
				check = 0;
			}
			var cname = global.data.cacheName[id];
			if (cname == undefined){
				cname = "ko xác định";
				check = 0;
			}
		    if (check = 1){
				data1 += `${cname} - ${times} tin nhắn\r\n`;
			}
		} 
		return {
			handler: "internal",
			data: data1
		}
	} 
	else if (data.msgdata.body.indexOf("all") != -1){
	    var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
		var participantIDs = threadInfo.participantIDs.map(x => x.toString());
		var data1 = "";
		var check = 1;
        for (var y in participantIDs){
			var id = participantIDs[y];
			var times = global.data.countchat[data.msgdata.threadID][id];
			if (times == undefined){
				times = 0;
				check = 0;
			}
			var cname = global.data.cacheName["FB-"+id];
			if (cname == undefined){
				cname = "ko xác định";
				check = 0;
			}
		    if (check = 1){
				data1 += `${cname} - ${times} tin nhắn\r\n`;
			}
		}
		return {
			handler: "internal",
			data: data1
		}
	}
	else if (data.msgdata.body == global.config.commandPrefix+"countchat"){
		var data1 = "";
		var check = 1;
		var id = getID(data.msgdata, type);
		var times = global.data.countchat[data.msgdata.threadID][(id.slice(3,id.length))];
		if (times == undefined){
			times = 0;
			check = 0;
		}
		var cname = global.data.cacheName[id];
		if (cname == undefined){
			cname = "ko xác định";
			check = 0;
		}
        if (check = 1){
			data1 += `${cname} - ${times} tin nhắn\r\n`;
		}
		return {
			handler: "internal",
			data: data1
		}
	} else {
		return {
			handler: "internal",
			data: "wrong!"
		}
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*if (data.msgdata.body.indexOf("@") != -1){
		var data = "";
        for (var y in data.mentions){
			var id = y.slice(3,y.length);
			console.log(id);
			console.log(y);
			var times = global.data.countchat[data.msgdata.threadID].id;
			var name = global.data.cacheName[y];
			console.log(times);
			console.log(name);
		    data += `${name}: ${times} tin nhắn`;
		}
		return {
			handler: "internal",
		    data: data
		}
	}
	else if (data.msgdata.body.indexOf("all") != -1){

	}
	else {
		return {
			handler: "internal",
		    data: "too few args!"
		}
	}
}
var chathook = function(type, data){
	typeof global.data.countchat != "object" ? global.data.countchat = {} : "";
	typeof global.data.countchat[data.msgdata.threadID] != "object" ? global.data.countchat[data.msgdata.threadID] = {} : "";
    !global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] ? global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] = [] : "";
	if(global.data.countchat[data.msgdata.threadID].allow == 1){
	    if(global.data.countchat[data.msgdata.threadID][data.msgdata.senderID].length == 0){
		    global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] = 1;
	    }
    	else if (global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] != 0 && global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] != null){
		    global.data.countchat[data.msgdata.threadID][data.msgdata.senderID] = global.data.countchat[data.msgdata.threadID][data.msgdata.senderID]+1;
	    }
	    else {
    		return {
			    handler: "internal",
		        data: "error at countchat plugin!"
	    	}
    	}
    }
}
*/
module.exports = {
	start,
	stop,
	chathook,
	reset,
	show
}