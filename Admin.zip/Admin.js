var wait = global.nodemodule["wait-for-stuff"];
var admin = function(type, data) {
	return {
		handler: "internal",
		data: "fb.com/thangtrickerga"
	}
}


module.exports = {
	admin
}